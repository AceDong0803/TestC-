//
//  BookStoreDemo.cpp
//  CppDemoApp
//
//  Created by Ace on 2020/11/16.
//

#include "BookStoreDemo.hpp"
#include <array>
#include <stdio.h>
#include <iostream>

#define S(str) CryptString(str).Decrypt()

//第一步，搞个简单的加密算法
const unsigned char XORKEY0[] = { 0x45, 0x76, 0x31, 0x59, 0x81 };
const unsigned char XORKEY1[] = { 0x86, 0xD9, 0x19, 0x0f, 0x38, 0xa9, 0x6c };

// 加密
template<class T>
constexpr T EncryptTByte(const T b, int index)
{
 return b ^ (T)(XORKEY0[index % sizeof(XORKEY0)] + XORKEY1[index % sizeof(XORKEY1)] + index);
}

// 解密。由于是异或就直接调加密的。
template<class T>
inline constexpr T DecryptTByte(const T b, int index)
{
 return EncryptTByte(b, index);
}


//然后写个类，在构造时将原文加密后存储：
template <class T, size_t N>
struct CCryptString
{
public:
 template<size_t... StrIndex>
  inline constexpr  CCryptString(const T * str, std::index_sequence<StrIndex...>) : m_buffer{ EncryptTByte(str[StrIndex], StrIndex)... }
 {
 }

    //实现解密的函数，在运行的时候，将加密后的还原回来：
    T * Decrypt()
     {
      for (int t = 0; t < N; t++)
      {
       m_buffer[t] = DecryptTByte(m_buffer[t], t);
      }
      return m_buffer.data();
     }
    
    //再添加一个类型转换，方便使用：
    operator T * ()
     {
      return this->Decrypt();
     }

private:
 std::array<T, N + 1> m_buffer;
};

//使用宏包装一层：
template<class T, size_t N>
inline constexpr auto CryptString(const T (&str)[N])
{
 return CCryptString<T, N>(str, std::make_index_sequence<N>());
}



void BookStore::runSellBook(){
//    int v1,v2;
//    std::cin >> v1 >> v2;
    std::cout << S("TestAcb") << std::endl;
}
