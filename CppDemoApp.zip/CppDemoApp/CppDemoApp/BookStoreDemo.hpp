//
//  BookStoreDemo.hpp
//  CppDemoApp
//
//  Created by Ace on 2020/11/16.
//


#include <iostream>
#ifndef BookStoreDemo_hpp
#define BookStoreDemo_hpp

#include <stdio.h>


class BookStore {
    
public:
    void runSellBook();
};



#endif /* BookStoreDemo_hpp */
