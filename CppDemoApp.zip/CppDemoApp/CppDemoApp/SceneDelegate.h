//
//  SceneDelegate.h
//  CppDemoApp
//
//  Created by Ace on 2020/11/16.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

