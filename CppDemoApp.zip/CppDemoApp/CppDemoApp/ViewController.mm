//
//  ViewController.m
//  CppDemoApp
//
//  Created by Ace on 2020/11/16.
//

#import "ViewController.h"
#include "BookStoreDemo.hpp"

@interface ViewController ()
@property (atomic,assign)NSInteger index;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    dispatch_async(dispatch_get_global_queue(0, 0), ^{
//        [self callSelf];
//    });
//    [self callSelf];
    
    BookStore bookStore;
    bookStore.runSellBook();
    
}


- (void)callSelf{
//    self.index = 10;
    [self callSelf];
}

@end
